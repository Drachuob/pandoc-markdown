---
title: 'Document de présentation de pandoc'
title-short: 'Pandoc'
date: 26/04/2038
lang: fr-FR

author:
    - Cyrvan Bouchard

abstract: 'This is the abstarct.'

subtitle: Document de présentation de l'outil pandoc
institute: None

papersize: a4
documentclass: article

fontsize: 32pt
fontfamily: FiraSans

---

\maketitle
\pagebreak
\tableofcontents
\pagebreak

# Section #######

## Texte {.title} 

*Un* **peu** ~~de~~ de texte.

\pagebreak

## Image

![Image de chat](chat.png "Chat.")

\pagebreak

## Citation

> Citation \
> Citation \
> Citation \

\pagebreak

## Listes

Liste:

* Item1
    + Item1.1
        - Item1.1.1
        - Item1.1.2
* Item2
* Item3

Liste numérotée:

#. Item1
#. Item2
#. Item2

\pagebreak

# Lien dans le document

Voir [l'introduction](#introduction)

# Lien

[Lien](https://pandoc.org/MANUAL.html#horizontal-rules) vers la documentation de pandoc.

\pagebreak

## Code

~~~~~~~ {#id .python .numberLines startFrom="3"}
#!/usr/bin/env python3
from time import localtime
heure = localtime().tm_hour
if heure < 17:
    print("Bonjour !")
else:
    print("Bonsoir !")
~~~~~~~
